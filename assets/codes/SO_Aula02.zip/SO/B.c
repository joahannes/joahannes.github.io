#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int **matriz;
    int l = 0;

    // Alocar dinamicamente uma matriz 20000x20000
    int tamanho = 20000;
    matriz = (int **)malloc(tamanho * sizeof(int *));
    for (int i = 0; i < tamanho; i++) {
        matriz[i] = (int *)malloc(tamanho * sizeof(int));
    }

    if (matriz == NULL) {
        printf("Erro ao alocar memória!\n");
        return 1;
    }

    // Percorrer a matriz
    for (int i = 0; i < tamanho; i++) {
        for (int j = 0; j < tamanho; j++) {
            l = matriz[j][i];
        }
    }
    // Liberar a memória alocada
    for (int i = 0; i < tamanho; i++) {
        free(matriz[i]);
    }
    free(matriz);

    printf("Programa B");

    return 0;
}
