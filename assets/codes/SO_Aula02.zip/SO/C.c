#include <stdio.h>
#include <stdlib.h>

int main() {
    int matriz[1000][1000];
    int l = 0;
    int tamanho = 1000;

    // Percorrer a matriz
    for (int i = 0; i < tamanho; i++) {
        for (int j = 0; j < tamanho; j++) {
            l = matriz[i][j];
        }
    }

    printf("Programa C");

    return 0;
}
