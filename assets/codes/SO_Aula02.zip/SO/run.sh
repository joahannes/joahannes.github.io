#!/bin/bash
#Author: Joahannes B. D. da Costa <joahannes.costa@unifesp.br>

echo "Compilando e executando o Programa A"
gcc -o A A.c && time ./A

echo "Aguardando 2 segundos"
sleep 2

echo "Compilando e executando o Programa B"
gcc -o B B.c && time ./B

echo "Removendo os programas"
rm A
rm B
