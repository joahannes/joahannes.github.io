import flwr as fl

outputs = fl.server.start_server(
    server_address  = '127.0.0.1:9090',
    config          = fl.server.ServerConfig(num_rounds=10),
    strategy        = fl.server.strategy.FedAvg()
)

print("Output Federated Learning - Loss/Round: ", outputs.losses_distributed)