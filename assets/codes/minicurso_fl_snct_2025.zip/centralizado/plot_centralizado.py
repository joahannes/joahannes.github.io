import matplotlib.pyplot as plt
import numpy as np

tamanho_fonte = 15

def plot_acc():

	dados = {}
	for i in open('treino.txt'):
		valor = i.split()
		if valor[3] != "val_acc":
			print(valor[0], valor[3])
			id = valor[0]
			acc = valor[3]

			if id not in dados:
				dados[id] = []
				dados[id].append(float(acc))
			else:
				dados[id].append(float(acc))

	fig = plt.gcf()

	plt.plot(dados.values(), marker='s', color='r', ls="--", linewidth=3, markersize=10)

	xticks = np.arange(0,10,1)
	labels = np.arange(1,11,1)
	plt.xticks(xticks, labels, fontsize=tamanho_fonte)

	plt.xlim(-0.5,9.5)

	yticks = np.arange(0.91, 1.01, 0.01)
	plt.yticks(yticks, fontsize=tamanho_fonte)

	plt.xlabel("Época de treinamento", fontsize=tamanho_fonte)
	plt.ylabel("Acurácia", fontsize=tamanho_fonte)

	plt.grid(color='grey', linestyle='--', linewidth=2, axis='both', alpha=0.1)
	plt.title("Centralizado com dataset MNIST")
	fig.savefig('Acuracia_Centralizado.png', dpi=200, bbox_inches = 'tight', pad_inches = 0.05)

	plt.close()

def plot_loss():

	dados = {}
	for i in open('treino.txt'):
		valor = i.split()
		if valor[4] != "val_loss":
			print(valor[0], valor[4])
			id = valor[0]
			acc = valor[4]

			if id not in dados:
				dados[id] = []
				dados[id].append(float(acc))
			else:
				dados[id].append(float(acc))

	fig = plt.gcf()

	plt.plot(dados.values(), marker='s', color='b', ls='--', linewidth=3, markersize=10)

	xticks = np.arange(0,10,1)
	labels = np.arange(1,11,1)
	plt.xticks(xticks, labels, fontsize=tamanho_fonte)
	plt.yticks(fontsize=tamanho_fonte)
	
	plt.xlim(-0.5,9.5)

	plt.xlabel("Época de treinamento", fontsize=tamanho_fonte)
	plt.ylabel("Loss", fontsize=tamanho_fonte)

	plt.grid(color='grey', linestyle='--', linewidth=2, axis='both', alpha=0.1)
	plt.title("Centralizado com dataset MNIST")
	fig.savefig('Loss_Centralizado.png', dpi=200, bbox_inches = 'tight', pad_inches = 0.05)

	plt.close()

plot_acc()
plot_loss()